<?php

$databaseHost = 'localhost';
$databaseName = 'dailydaima';
$databaseUsername = 'root';
$databasePassword = 'root';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);

?>